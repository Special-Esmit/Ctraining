C Training Project
Phonebook: ELF 64-bit LSB pie executable, x86-64, version 1 (SYSV), dynamically linked, interpreter /lib64/ld-linux-x86-64.so.2, BuildID[sha1]=bc1f352bfcd2accc8d3aab8257470abcc56d8445, for GNU/Linux 4.4.0
Phonebook.c : source file