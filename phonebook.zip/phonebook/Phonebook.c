
#include <stdio.h>
#include <string.h>

int main(){
    printf("<$> C trainin repo by special.esmit\n<$> Join us to babye\nhttps://t.me/RemaxBoxTeam\n<$> by @thelastidea\n\n");
    int total,i;
    printf("<*> Enter total value : ");
    scanf("%d",&total);

    struct person {
        char name[31];
        char phone[31];
    } slice[total+1];

    for(i = 0 ; i <= total-1 ; i++){
        char phone_input[31],name_input[31];
        printf("<*> Enter Name : ");
        scanf(" %s",&name_input);
        printf("<*> Enter Phone : ");
        scanf(" %s",&phone_input);
        printf("________________\n<*> Name : %s\n<*> Phone : %s\n________________\n",name_input,phone_input);
        strncpy(slice[i].name, name_input , 31);
        strncpy(slice[i].phone, phone_input, 31);
    }
    
    int d;
    char name_outp[31],phone_outp[31];

    for(d = 0 ; d <= total-1 ; d++){
        strncpy(name_outp, slice[d].name, 31);
        strncpy(phone_outp, slice[d].phone, 31);
        printf("________________________________\n<*> The table content\n<*>Name in the table : %s\n<*> Phone number in table : %s\n",name_outp,phone_outp);
    }
    printf("\n<*> The end <*>\n");
    return 0;
}
